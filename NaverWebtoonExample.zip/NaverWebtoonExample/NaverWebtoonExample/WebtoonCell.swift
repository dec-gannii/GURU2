//
//  WebtoonCell.swift
//  NaverWebtoonExample
//
//  Created by 김가은 on 2021/07/07.
//

import UIKit

// 어떤 클래스 상속 -> 이미 구현되어 있는 기능을 가져다 사용하겠다는 의미
// 그 중에 일부만 커스터마이징 해서 사용하겠음 <- 목적
class WebtoonCell:UICollectionViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var authorLabel: UILabel!
    @IBOutlet weak var titleImage: UIImageView!
    
    
}
