//
//  ViewController.swift
//  NaverWebtoonExample
//
//  Created by 김가은 on 2021/07/07.
//

import UIKit

class ViewController: UIViewController {
    var webtoonData = [
        WebToonData("전지적 독자 시점", "image01", 5, "싱숑,UMI / 슬리피-C"),
        WebToonData("남주의 첫날밤을 가져버렸다", "image02", 4.3, "황도톨,티바 / MSG"),
        WebToonData("독립일기", "image03", 4.8, "자까"),
        WebToonData("노답소녀", "image04", 4.7, "석우"),
        WebToonData("엔딩 후 서브남을 주웠다", "image05", 4.0, "황도톨,정서 / 정서"),
        WebToonData("피라미드 게임", "image06", 4.9, "달꼬냑"),
        WebToonData("외모지상주의", "image07", 4.9, "박태준"),
        WebToonData("갓 오브 하이스쿨", "image08", 4.9, "박용제"),
        WebToonData("모죠의 일지", "image09", 4.9, "모죠"),
        WebToonData("호랑이 형님", "image10", 4.9, "이상규")
    ]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

extension ViewController:UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return webtoonData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "webToobCell", for: indexPath) as! WebtoonCell
        // Todo : Title, Stars, Authors 채우기
        let data = webtoonData[indexPath.row]
        cell.titleLabel.text = data.title
        cell.ratingLabel.text = "\(data.rating!)"
        cell.authorLabel.text = data.author
        // title image 변경
        cell.titleImage.image = UIImage(named: data.title_image)
        // 회색 테두리 적기
        cell.layer.borderWidth = 0.3
        cell.layer.borderColor = UIColor.lightGray.cgColor
        
        return cell
    }
}

extension ViewController:UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        // let width = self.view.frame.size.width / 3 // 3개씩 들어가도록
        let width = UIScreen.main.bounds.width / 3 // 3개씩 들어가도록
        let height = width * 1.5
        
        return CGSize(width: width, height: height)
    }
}
